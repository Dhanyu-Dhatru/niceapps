package com.dd.devotional.rashiphalalu;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.dd.devotional.rashiphalalu.com.dd.utils.AdUtil;
import com.google.android.gms.ads.InterstitialAd;

public class DisplayChapter extends AppCompatActivity {
    private static WebSettings.TextSize viewTextSize = WebSettings.TextSize.NORMAL;
    WebSettings ws =null;
    InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String URL_TO_LOAD="http://apphelper5555.net/dphal/DinPhal.php";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_chapter);
        WebView webView = ((WebView)findViewById(R.id.webView));
        if(isNetworkAvailable())
        {
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadUrl(URL_TO_LOAD);
           new AdUtil(this,getApplicationContext().getPackageName());
        }
        else
        {
            webView.loadUrl("file:///android_asset/nonet.html");
        }


    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_display_chapter, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.font_largest:
                viewTextSize = WebSettings.TextSize.LARGEST;
                break;
            case R.id.font_larger:
                viewTextSize = WebSettings.TextSize.LARGER;
                break;
            case R.id.font_normal:
                viewTextSize = WebSettings.TextSize.NORMAL;
                break;
            case R.id.font_small:
                viewTextSize = WebSettings.TextSize.SMALLER;

                break;
            case R.id.font_smallest:
                viewTextSize = WebSettings.TextSize.SMALLEST;

                break;
        }
        //noinspection SimplifiableIfStatement
        ws.setTextSize(viewTextSize);
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
