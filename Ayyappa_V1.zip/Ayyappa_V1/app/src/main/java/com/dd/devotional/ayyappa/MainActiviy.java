package com.dd.devotional.ayyappa;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActiviy extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activiy);
          }

    public void onClick(View v) {
        Intent intent = new Intent(MainActiviy.this, PlayStory.class);
        //String tags[]=v.getTag().toString().split(";");
        //intent.putExtra("STORY_URL", v.getTag().toString());
        String MP3_URL="";
        String HTML_NAME="";
        switch (v.getId())
        {
            case R.id.btnPuja:
                MP3_URL="puja.mp3";
                HTML_NAME="puja";
                break;

            case R.id.btnAbout:
                MP3_URL="about.mp3";
                HTML_NAME="lokaveeram";
                break;

            case R.id.btnHarathi:
                MP3_URL="harathi.mp3";
                HTML_NAME="harathi";
                break;

            case R.id.btnKatha:
                MP3_URL="about.mp3";
                HTML_NAME="ninadalu";
                break;

            case R.id.btnSamagri:
                MP3_URL="samagri.mp3";
                HTML_NAME="niyamalu";
                break;

        }
        intent.putExtra("MP3_URL", MP3_URL);
        intent.putExtra("HTML_NAME", HTML_NAME);
        startActivity(intent);
    }


}
