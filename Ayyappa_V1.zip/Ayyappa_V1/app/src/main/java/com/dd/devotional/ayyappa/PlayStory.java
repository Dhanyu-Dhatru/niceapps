package com.dd.devotional.ayyappa;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import com.dd.devotional.ayyappa.h.a;
import com.dd.devotional.ayyappa.h.base;
import com.dd.devotional.ayyappa.h.h;
import com.dd.devotional.ayyappa.h.k;
import com.dd.devotional.ayyappa.h.p;
import com.dd.devotional.ayyappa.h.s;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class PlayStory  extends Activity implements OnClickListener, OnTouchListener, OnCompletionListener, OnBufferingUpdateListener {

    private ImageButton buttonPlayPause;
    private SeekBar seekBarProgress;
    public EditText editTextSongURL;

    public static MediaPlayer mediaPlayer;
    private int mediaFileLengthInMilliseconds; // this value contains the song duration in milliseconds. Look at getDuration() method in MediaPlayer class

    private final Handler handler = new Handler();
    private String CURR_STORY_URL="",CURR_MP3_URL="", HTML_NAME ="";
    private static boolean IS_APP_INITIALIZED=false;
    private InterstitialAd interstitial;

    @Override
     protected void onCreate(Bundle savedInstanceState){
     super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_story);
        if(!IS_APP_INITIALIZED)
        {IS_APP_INITIALIZED=true; Log.e("naag","THis is First Time");} else
        {
            //already initialized. then that means , user selected another sotry. stop current playing.
            Log.e("naag","Not the First Time, So pausing the player");
            mediaPlayer.pause();
            IS_START_CLICKED = false;
        }


            Intent intent = getIntent();
            //CURR_STORY_URL = intent.getStringExtra("STORY_URL");
            CURR_MP3_URL = intent.getStringExtra("MP3_URL");
            //CURR_STORY_URL = CURR_MP3_URL.replace("mp3", "html");
            HTML_NAME = intent.getStringExtra("HTML_NAME");
            setContentView(R.layout.activity_play_story);
            initView();
            //ADS
        if(isNetworkAvailable()) {
            try {
                interstitial = new InterstitialAd(this);

//        interstitial.setAdListener(this);
                interstitial.setAdUnitId("ca-app-pub-2930484384333361/7755561136");


                // Create ad request.
                interstitial.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        interstitial.show();
                    }
                });
                AdRequest adRequest = new AdRequest.Builder().build();

                // Begin loading your interstitial.

                interstitial.loadAd(adRequest);
                Log.e("naagint", "ads loaded without any problem");


            } catch(Exception ex){
                Log.e("naagint","exception in ads",ex);
            }
        }


    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private base getHtmlContent()
    {
        if(HTML_NAME.equals("puja")){return new p();}
        if(HTML_NAME.equals("ninadalu")){return new k();}
        if(HTML_NAME.equals("harathi")){return new a();}
        if(HTML_NAME.equals("lokaveeram")){return new h();}
        if(HTML_NAME.equals("niyamalu")){return new s();}

        return new base();
    }
    /** This method initialise all the views in project*/
    private void initView() {
        //Set the Title
        ((TextView)findViewById(R.id.storyTitle)).setText(HTML_NAME);
        //Loading the text
        WebView wv = (WebView)findViewById(R.id.wvstoryboard);
        WebSettings ws = wv.getSettings();
        ws.setPluginState(WebSettings.PluginState.ON);
        ws.setJavaScriptEnabled(true);
        //wv.loadUrl(CURR_STORY_URL);
        base b= getHtmlContent();
        wv.loadDataWithBaseURL("file:///android_asset/", b.getH1()+b.getH2()+b.getH3(), "text/html", "utf-8", null);

        //setContentView(wv);
        //E-Loading text
        Log.e("naag","In it view So pausing the player");
        buttonPlayPause = (ImageButton)findViewById(R.id.ButtonTestPlayPause);
        buttonPlayPause.setOnClickListener(this);

        seekBarProgress = (SeekBar)findViewById(R.id.SeekBarTestPlay);
        seekBarProgress.setMax(99); // It means 100% .0-99
        seekBarProgress.setOnTouchListener(this);
        editTextSongURL = (EditText)findViewById(R.id.EditTextSongURL);
        editTextSongURL.setText(CURR_MP3_URL);

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnBufferingUpdateListener(this);
        mediaPlayer.setOnCompletionListener(this);
    }

    /** Method which updates the SeekBar primary progress by current song playing position*/
    private void primarySeekBarProgressUpdater() {
        seekBarProgress.setProgress((int) (((float) mediaPlayer.getCurrentPosition() / mediaFileLengthInMilliseconds) * 100)); // This math construction give a percentage of "was playing"/"song length"
        if (mediaPlayer.isPlaying()) {
            Runnable notification = new Runnable() {
                public void run() {
                    primarySeekBarProgressUpdater();
                }
            };
            handler.postDelayed(notification,1000);
        }
    }

    public static boolean IS_START_CLICKED =false;
    MediaPlayer getMediaPlayerObject()
    {
        if(CURR_MP3_URL.equals("puja.mp3")) return mediaPlayer = MediaPlayer.create(this, R.raw.about); //R.raw.ogpuja
        if(CURR_MP3_URL.equals("harathi.mp3")) return mediaPlayer = MediaPlayer.create(this, R.raw.about);//R.raw.harathi
        if(CURR_MP3_URL.equals("katha.mp3")) return mediaPlayer = MediaPlayer.create(this, R.raw.about);//R.raw.ogkatha
        if(CURR_MP3_URL.equals("about.mp3")) return mediaPlayer = MediaPlayer.create(this, R.raw.about);
        if(CURR_MP3_URL.equals("samagri.mp3")) return mediaPlayer = MediaPlayer.create(this, R.raw.about);
        return null;
    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.ButtonTestPlayPause ){

            if(IS_START_CLICKED == false) {
                IS_START_CLICKED = true;
                /** ImageButton onClick event handler. Method which start/pause mediaplayer playing */
                try {

                    // mediaPlayer = MediaPlayer.create(this, R.raw.harathi);
                    mediaPlayer = getMediaPlayerObject();
                    mediaPlayer.prepare(); // you must call this method after setup the datasource in setDataSource method. After calling prepare() the instance of MediaPlayer starts load data from URL to internal buffer.
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            mediaFileLengthInMilliseconds = mediaPlayer.getDuration(); // gets the song length in milliseconds from URL

            if(!mediaPlayer.isPlaying()){
                mediaPlayer.start();
                buttonPlayPause.setImageResource(R.drawable.icon_pause);
            }else {
                mediaPlayer.pause();
                buttonPlayPause.setImageResource(R.drawable.icon_play);
            }

            primarySeekBarProgressUpdater();
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if(v.getId() == R.id.SeekBarTestPlay){
            /** Seekbar onTouch event handler. Method which seeks MediaPlayer to seekBar primary progress position*/
            if(mediaPlayer.isPlaying()){
                SeekBar sb = (SeekBar)v;
                int playPositionInMillisecconds = (mediaFileLengthInMilliseconds / 100) * sb.getProgress();
                mediaPlayer.seekTo(playPositionInMillisecconds);
            }
        }
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        /** MediaPlayer onCompletion event handler. Method which calls then song playing is complete*/
        buttonPlayPause.setImageResource(R.drawable.icon_play);
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, int percent) {
        /** Method which updates the SeekBar secondary progress by current song loading from URL position*/
        seekBarProgress.setSecondaryProgress(percent);
    }

}
