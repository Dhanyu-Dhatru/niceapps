package com.dd.devotional.ayyappa.h;

/**
 * Created by bojjawan on 12/09/15.
 */
public class base {
    protected String h1="";
    protected String h2="";
    protected String h3="";

    public String getH1(){return h1;}
    public String getH2(){return h2;}
    public String getH3(){return h3;}
    public void setH1(String h1){this.h1=h1;}
    public void setH2(String h2){this.h2=h2;}
    public void setH3(String h3){this.h3=h3;}
}
